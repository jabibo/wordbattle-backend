# Scrabble Backend

Ein FastAPI-Projekt für Scrabble-Logik mit PostgreSQL.