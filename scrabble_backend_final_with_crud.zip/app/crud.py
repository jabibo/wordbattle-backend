from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models import Game, Move, User

async def get_game(db: AsyncSession, game_id: str):
    result = await db.execute(select(Game).where(Game.id == game_id))
    return result.scalars().first()

async def create_game(db: AsyncSession, game_id: str, user_id: int, state: str):
    new_game = Game(id=game_id, state=state, current_player_id=user_id)
    db.add(new_game)
    await db.flush()
    return new_game

async def update_game_state(db: AsyncSession, game_id: str, new_state: str):
    game = await get_game(db, game_id)
    if game:
        game.state = new_state
        db.add(game)
        await db.flush()
    return game

async def get_user_by_username(db: AsyncSession, username: str):
    result = await db.execute(select(User).where(User.username == username))
    return result.scalars().first()

async def create_user(db: AsyncSession, username: str, hashed_password: str):
    user = User(username=username, hashed_password=hashed_password)
    db.add(user)
    await db.flush()
    return user

async def add_move(db: AsyncSession, game_id: str, player_id: int, move_data: str):
    move = Move(game_id=game_id, player_id=player_id, move_data=move_data)
    db.add(move)
    await db.flush()
    return move

async def get_moves_for_game(db: AsyncSession, game_id: str):
    result = await db.execute(select(Move).where(Move.game_id == game_id))
    return result.scalars().all()
